package com.example.demo.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.example.demo.entities.caracteristique;
import com.example.demo.entities.pets;

public interface Petservice {
	pets savePets(pets pet);
	pets updatePets(pets pet);
	void deletePets(pets pet);
	void deletePetById(Long id);
	pets getPet(Long id);
	List<pets> getAllPets();
	Page<pets> getAllpetsParPage(int page, int size);
	List<pets> findBynompet(String nom);
	List<pets> findBynompetContains(String nom);
	List<pets> findBynompetprixpet (String nom, Double prix);
	List<pets> findBycaracteristique (caracteristique caracteristique);
	List<pets> findByCaracteristiqueIdCat(Long id);
	//List<pets> findByOrderBynompetAsc();
	List<pets> trierpetsprixpet();

}
