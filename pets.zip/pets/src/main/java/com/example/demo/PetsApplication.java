package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.entities.pets;
import com.example.demo.service.Petservice;

@SpringBootApplication
public class PetsApplication  implements CommandLineRunner  {
	
	@Autowired
	Petservice petService;
	
	public static void main(String[] args) {
		SpringApplication.run(PetsApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		petService.savePets(new pets("Chien", "chouchou","bagira",2000));
		petService.savePets(new pets("Chien", "bildog","oscar",953));
		petService.savePets(new pets("Chat", "pensan","jamilaa",352));
}
}
