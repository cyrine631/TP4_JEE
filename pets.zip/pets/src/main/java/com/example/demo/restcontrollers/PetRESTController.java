package com.example.demo.restcontrollers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.pets;
import com.example.demo.service.Petservice;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class PetRESTController {

	@Autowired
	Petservice petService;
	
	@RequestMapping(method = RequestMethod.GET)
	public List<pets> getAllPets() {
	return petService.getAllPets();
	}
	
	@RequestMapping(value="/{id}",method = RequestMethod.GET)
	public pets getPetById(@PathVariable("id") Long id) {
		return petService.getPet(id);
		 }
	
	@RequestMapping(method = RequestMethod.POST)
	public pets createPet(@RequestBody pets pet) {
		return petService.savePets(pet);
		}

	@RequestMapping(method = RequestMethod.PUT)
	public pets updatePet(@RequestBody pets pet) {
		return petService.updatePets(pet);
		}
	
	@RequestMapping(value="/{id}",method = RequestMethod.DELETE)
	public void deletePet(@PathVariable("id") Long id)
	{
		petService.deletePetById(id);
	}
	
	@RequestMapping(value="/caracteristique_id_cat/{idCat}",method = RequestMethod.GET)
	public List<pets> getPetsByCatId(@PathVariable("idCat") Long idCat) {
		return petService.findByCaracteristiqueIdCat(idCat);
		}

}
