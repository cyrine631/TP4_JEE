package com.example.demo.repos;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entities.caracteristique;
import com.example.demo.entities.pets;


public interface PetsRepository extends JpaRepository<pets, Long> {

	List<pets> findBynompet(String nompet);
	List<pets> findBynompetContains(String nompet);
	
	@Query("select pe from pets pe where pe.nompet like %:nompet and pe.prixpet  >:prixpet")
	List<pets> findBynompetprixpet (@Param("nompet") String nompet,@Param("prixpet") Double prixpet); 
	
	@Query("select pe from pets pe where pe.caracteristique = ?1")
	List<pets> findBycaracteristique (caracteristique caracteristique);
	
	List<pets> findByCaracteristiqueIdCat(Long id);
	
	//List<pets> findByorderbynompetAsc();

	@Query("select pe from pets pe order by pe.nompet ASC, pe.prixpet DESC")
	List<pets> trierpetsprixpet ();
	
}
