package com.example.demo;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;

import com.example.demo.entities.caracteristique;
import com.example.demo.entities.pets;
import com.example.demo.repos.PetsRepository;
import com.example.demo.service.Petservice;


@SpringBootTest
class PetsApplicationTests {

	@Autowired
	private PetsRepository petRepository;
	private Petservice petservice;

	@Test
	public void testCreatePet() {
	pets pets = new pets("wshifa","cat","siamois",70);
	petRepository.save(pets);
	}
	
	@Test
	public void testFindPet()
	{
	pets pet = petRepository.findById(28L).get();
	System.out.println(pet);
	}
	
	@Test
	public void testUpdatePet()
	{
		pets pet = petRepository.findById(28L).get();
		pet.setPrixpet(120);
		petRepository.save(pet);
	}
	 
	@Test
	public void testDeletePet()
	{
		petRepository.deleteById(29L);;
	}
	
	@Test
	public void testListerTousPet()
	{
	List<pets> pets = petRepository.findAll();
	for (pets pe : pets)
	{
	System.out.println(pe);
	}
	}
	@Test
	public void testFindByNompetContains()
	{
	Page<pets> prods = petservice.getAllpetsParPage(0,2);
	System.out.println(prods.getSize());
	System.out.println(prods.getTotalElements());
	System.out.println(prods.getTotalPages());
	prods.getContent().forEach(p -> {
		System.out.println(p.toString());
		});
	 }
	@Test
	public void testfindBynompetprixpet()
	{
	List<pets> pe = petRepository.findBynompetprixpet("wshifa", 70.00);
	for (pets p : pe)
	{
	System.out.println(p);
	}
	}
	
	@Test
	public void testfindBycaracteristique()
	{
	caracteristique cat = new caracteristique();
	cat.setIdCat(28L);
	List<pets> prods = petRepository.findBycaracteristique(cat);
	for (pets p : prods)
	{
	System.out.println(p);
	}
	}
	
	@Test
	public void testfindByCaracteristiqueIdCat()
	{
	List<pets> prods = petRepository.findByCaracteristiqueIdCat(1L);
	for (pets p : prods)
	{
	System.out.println(p);
	}
	 }

	/*@Test
	public void testfindByorderbynompetAsc()
	{
	List<pets> prods = petRepository.findByorderbynompetAsc();
	for (pets p : prods)
	{
	System.out.println(p);
	}
	}*/
	
	@Test
	public void testtrierpetsprixpet()
	{
	List<pets> pets = petRepository.trierpetsprixpet();
	for (pets pet : pets)
	{
	System.out.println(pet);
	}

	}
}
