package com.example.demo.controllers;

import java.text.ParseException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entities.pets;
import com.example.demo.service.Petserviceimp;

@Controller
public class petController {

	@Autowired
	Petserviceimp Petservice;
	@RequestMapping("/showCreate")
	public String showCreate(ModelMap modelMap)
	{
		modelMap.addAttribute("pets", new pets());
		modelMap.addAttribute("mode", "new");
		return "formPet";
	
	}
	@RequestMapping("/savePets")
	public String saveProduit(@Valid pets pet, BindingResult bindingResult)
	
	{
		if (bindingResult.hasErrors()) return "formPet";
		Petservice.savePets(pet);
		return "formPet";
		}
	
	@RequestMapping("/ListePets")
	public String ListePets(ModelMap modelMap,
	@RequestParam (name="page",defaultValue = "0") int page,
	@RequestParam (name="size", defaultValue = "2") int size)
	{
	Page<pets> pets = Petservice.getAllpetsParPage(page, size);;
	modelMap.addAttribute("pets", pets);
	modelMap.addAttribute("pages", new int[pets.getTotalPages()]);
	modelMap.addAttribute("currentPage", page);
	return "ListePets";
	}
	
	@RequestMapping("/supprimerPet")
	public String supprimerPet(@RequestParam("id") Long id,
	 ModelMap modelMap,
	 @RequestParam (name="page",defaultValue = "0") int page,
	 @RequestParam (name="size", defaultValue = "2") int size)
	{
	Petservice.deletePetById(id);
	Page<pets> pets = Petservice.getAllpetsParPage(page,size);
	modelMap.addAttribute("pets", pets);
	modelMap.addAttribute("pages", new int[pets.getTotalPages()]);
	modelMap.addAttribute("currentPage", page);
	modelMap.addAttribute("size", size);
	return "ListePets";
	}


	@RequestMapping("/modifierPet")
	public String editerPet(@RequestParam("id") Long id,ModelMap modelMap)
	{
		pets  p= Petservice.getPet(id);
		modelMap.addAttribute("pets", p);
		modelMap.addAttribute("mode", "edit");
		return "editerPet";
	}
	@RequestMapping("/savePet")
	public String savePet(@ModelAttribute("pet") pets pet)
	{
		Petservice.savePets(pet);
	return "createPet";
	}
	@RequestMapping("/updatePet")
	public String updatePet(@ModelAttribute("pet") pets pet , ModelMap modelMap)
	{

		Petservice.updatePets(pet);
		List<pets> pets = Petservice.getAllPets();
		modelMap.addAttribute("pets", pets);
		return "ListePets";
		}
}
