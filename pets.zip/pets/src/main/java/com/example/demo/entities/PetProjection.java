package com.example.demo.entities;

import org.springframework.data.rest.core.config.Projection;

@Projection(name = "nomPet", types = { pets.class })
public interface PetProjection {
	public String getNompet();
}
